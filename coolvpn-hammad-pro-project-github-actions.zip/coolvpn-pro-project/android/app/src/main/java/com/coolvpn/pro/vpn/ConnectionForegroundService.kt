package com.coolvpn.pro.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.coolvpn.pro.MainActivity
import com.coolvpn.pro.R
import java.io.StringReader

/**
 * Owns the connection orchestration. The open-source ICS OpenVPN library owns
 * the actual TUN interface and encryption; this service imports the VPN Gate
 * profile, launches its permission flow, and forwards state to the UI.
 */
class ConnectionForegroundService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                startForeground(NOTIFICATION_ID, buildNotification(getString(R.string.connecting)))
                broadcastState(STATE_CONNECTING)
                val profile = intent.getStringExtra(EXTRA_CONFIG).orEmpty()
                val name = intent.getStringExtra(EXTRA_NAME).orEmpty()
                if (profile.isBlank() || !launchOpenVpnProfile(profile, name)) {
                    broadcastState(STATE_ERROR)
                    stopSelf()
                } else {
                    broadcastState(STATE_CONNECTED)
                }
            }
            ACTION_DISCONNECT -> {
                disconnectOpenVpn()
                broadcastState(STATE_DISCONNECTED)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun launchOpenVpnProfile(config: String, serverName: String): Boolean {
        return try {
            val parserClass = Class.forName("de.blinkt.openvpn.core.ConfigParser")
            val parser = parserClass.getDeclaredConstructor().newInstance()
            parserClass.getMethod("parseConfig", java.io.Reader::class.java)
                .invoke(parser, StringReader(config))
            val profile = parserClass.getMethod("convertProfile").invoke(parser)
            profile.javaClass.getField("mName").set(profile, "CoolVPN • $serverName")

            val managerClass = Class.forName("de.blinkt.openvpn.core.ProfileManager")
            val manager = managerClass.getMethod("getInstance", Context::class.java).invoke(null, this)
            managerClass.getMethod("addProfile", profile.javaClass).invoke(manager, profile)
            managerClass.getMethod("saveProfile", Context::class.java, profile.javaClass).invoke(manager, this, profile)

            val uuid = profile.javaClass.getMethod("getUUID").invoke(profile).toString()
            val launchClass = Class.forName("de.blinkt.openvpn.activities.LaunchVPN")
            val extraKey = launchClass.getField("EXTRA_KEY").get(null) as? String
                ?: "de.blinkt.openvpn.profileUUID"
            val launchIntent = Intent(this, launchClass).apply {
                putExtra(extraKey, uuid)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(launchIntent)
            true
        } catch (_: Throwable) {
            false
        }
    }

    private fun disconnectOpenVpn() {
        runCatching {
            val disconnectClass = Class.forName("de.blinkt.openvpn.activities.DisconnectVPN")
            startActivity(Intent(this, disconnectClass).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun broadcastState(state: String) {
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName).putExtra(EXTRA_STATE, state))
    }

    private fun buildNotification(content: String): Notification {
        val channelId = "coolvpn_connection"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channelId, getString(R.string.notification_channel), NotificationManager.IMPORTANCE_LOW)
            )
        }
        val launch = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_stat_vpn)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(content)
            .setContentIntent(launch)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_CONNECT = "com.coolvpn.pro.CONNECT"
        const val ACTION_DISCONNECT = "com.coolvpn.pro.DISCONNECT"
        const val ACTION_STATE = "com.coolvpn.pro.STATE"
        const val EXTRA_CONFIG = "extra_config"
        const val EXTRA_NAME = "extra_name"
        const val EXTRA_STATE = "extra_state"
        const val STATE_CONNECTING = "connecting"
        const val STATE_CONNECTED = "connected"
        const val STATE_DISCONNECTED = "disconnected"
        const val STATE_ERROR = "error"
        private const val NOTIFICATION_ID = 1201

        fun connect(context: Context, config: String, name: String) {
            ContextCompatCompat.start(context, Intent(context, ConnectionForegroundService::class.java).apply {
                action = ACTION_CONNECT
                putExtra(EXTRA_CONFIG, config)
                putExtra(EXTRA_NAME, name)
            })
        }

        fun disconnect(context: Context) {
            ContextCompatCompat.start(context, Intent(context, ConnectionForegroundService::class.java).setAction(ACTION_DISCONNECT))
        }
    }
}

private object ContextCompatCompat {
    fun start(context: Context, intent: Intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }
}