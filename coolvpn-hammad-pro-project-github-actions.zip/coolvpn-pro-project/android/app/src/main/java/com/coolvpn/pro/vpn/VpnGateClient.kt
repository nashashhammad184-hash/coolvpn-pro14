package com.coolvpn.pro.vpn

import android.util.Base64
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object VpnGateClient {
    private const val ENDPOINT = "https://www.vpngate.net/api/iphone/"
    private val executor = Executors.newSingleThreadExecutor()

    data class VpnServer(
        val hostName: String,
        val ip: String,
        val country: String,
        val countryCode: String,
        val ping: Int,
        val speed: Long,
        val sessions: Int,
        val config: String,
    )

    fun fetchOptimalServer(callback: (List<VpnServer>, Throwable?) -> Unit) {
        executor.execute {
            try {
                val connection = URL(ENDPOINT).openConnection() as HttpURLConnection
                connection.connectTimeout = 8_000
                connection.readTimeout = 8_000
                connection.requestMethod = "GET"
                val csv = connection.inputStream.bufferedReader().use { it.readText() }
                val servers = parseCsv(csv)
                if (servers.isEmpty()) error("No usable community VPN servers")
                callback(servers, null)
            } catch (error: Throwable) {
                callback(emptyList(), error)
            }
        }
    }

    private fun parseCsv(csv: String): List<VpnServer> {
        val lines = csv.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toList()
        val headerIndex = lines.indexOfFirst { it.removePrefix("#").startsWith("HostName,") }
        if (headerIndex < 0 || lines.size <= headerIndex + 1) return emptyList()
        val headers = splitCsv(lines[headerIndex].removePrefix("#")).map { it.lowercase() }
        fun index(name: String) = headers.indexOf(name.lowercase())
        val hostIndex = index("HostName")
        val ipIndex = index("IP")
        val countryIndex = index("CountryLong")
        val countryCodeIndex = index("CountryShort")
        val pingIndex = index("Ping")
        val speedIndex = index("Speed")
        val sessionsIndex = index("NumVpnSessions")
        val configIndex = index("OpenVPN_ConfigData_Base64")

        return lines.drop(headerIndex + 1).filterNot { it.startsWith("#") }.map { splitCsv(it) }.mapNotNull { fields ->
            val ping = fields.valueAt(pingIndex)?.toIntOrNull() ?: return@mapNotNull null
            val ip = fields.valueAt(ipIndex).orEmpty()
            if (ip.isBlank() || ping <= 0 || ping > 3000) return@mapNotNull null
            val encodedConfig = fields.valueAt(configIndex).orEmpty()
            val config = try {
                String(Base64.decode(encodedConfig, Base64.DEFAULT), Charsets.UTF_8)
            } catch (_: IllegalArgumentException) {
                ""
            }
            VpnServer(
                hostName = fields.valueAt(hostIndex) ?: "community-server",
                ip = ip,
                country = fields.valueAt(countryIndex) ?: "Community",
                countryCode = fields.valueAt(countryCodeIndex).orEmpty(),
                ping = ping,
                speed = fields.valueAt(speedIndex)?.toLongOrNull() ?: 0,
                sessions = fields.valueAt(sessionsIndex)?.toIntOrNull() ?: 0,
                config = config,
            )
        }.sortedBy { it.ping }.take(20)
    }

    private fun splitCsv(line: String): List<String> {
        val fields = mutableListOf<String>()
        val current = StringBuilder()
        var quoted = false
        line.forEach { character ->
            when {
                character == '"' -> quoted = !quoted
                character == ',' && !quoted -> {
                    fields += current.toString()
                    current.clear()
                }
                else -> current.append(character)
            }
        }
        fields += current.toString()
        return fields.map { it.trim().trim('"') }
    }

    private fun List<String>.valueAt(index: Int): String? = getOrNull(index)?.takeIf { it.isNotBlank() }
}