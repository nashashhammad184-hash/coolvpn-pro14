package com.coolvpn.pro.vpn

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability

class AdManager(private val context: Context) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var interstitial: InterstitialAd? = null
    private var isLoadingInterstitial = false
    private var googleMobileAdsAvailable = false

    fun initialize() {
        googleMobileAdsAvailable = isGoogleMobileAdsAvailable()
        if (!googleMobileAdsAvailable) return

        MobileAds.initialize(context) {
            preloadInterstitial()
        }
    }

    /**
     * Google Mobile Ads depends on Google Play Services. Huawei/Amazon
     * devices without GMS use the no-op provider path rather than crashing.
     * A real AppLovin MAX SDK key is required before enabling another network.
     */
    fun isAdProviderAvailable(): Boolean = googleMobileAdsAvailable

    /**
     * The VPN start request is made by MainActivity before this delayed,
     * ready-only ad attempt. An unavailable ad never blocks the VPN.
     */
    fun showConnectInterstitial(activity: Activity) {
        if (!googleMobileAdsAvailable) return

        mainHandler.postDelayed(
            { showReadyInterstitial(activity, afterClose = {}) },
            CONNECT_AD_DELAY_MS,
        )
    }

    /**
     * MainActivity remains in its disconnecting state until the ready ad is
     * dismissed. If no ad is ready, the bounded gate completes immediately.
     */
    fun showDisconnectInterstitial(activity: Activity, afterClose: () -> Unit) {
        if (!googleMobileAdsAvailable) {
            afterClose()
            return
        }

        mainHandler.postDelayed(
            { showReadyInterstitial(activity, afterClose) },
            DISCONNECT_AD_DELAY_MS,
        )
    }

    private fun showReadyInterstitial(activity: Activity, afterClose: () -> Unit) {
        if (activity.isFinishing ||
            (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && activity.isDestroyed)
        ) {
            afterClose()
            return
        }

        val readyAd = interstitial
        if (readyAd == null) {
            preloadInterstitial()
            afterClose()
            return
        }

        interstitial = null
        readyAd.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                preloadInterstitial()
                afterClose()
            }

            override fun onAdFailedToShowFullScreenContent(adError: com.google.android.gms.ads.AdError) {
                preloadInterstitial()
                afterClose()
            }
        }
        readyAd.show(activity)
    }

    private fun preloadInterstitial() {
        if (!googleMobileAdsAvailable) return
        if (interstitial != null || isLoadingInterstitial) return

        isLoadingInterstitial = true
        InterstitialAd.load(
            context,
            INTERSTITIAL_TEST_UNIT_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    isLoadingInterstitial = false
                    interstitial = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    isLoadingInterstitial = false
                    interstitial = null
                }
            },
        )
    }

    private fun isGoogleMobileAdsAvailable(): Boolean {
        return runCatching {
            GoogleApiAvailability.getInstance()
                .isGooglePlayServicesAvailable(context) == ConnectionResult.SUCCESS
        }.getOrDefault(false)
    }

    companion object {
        const val INTERSTITIAL_TEST_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"
        const val BANNER_TEST_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"
        private const val CONNECT_AD_DELAY_MS = 700L
        private const val DISCONNECT_AD_DELAY_MS = 250L
    }
}