package com.coolvpn.pro

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import com.coolvpn.pro.vpn.AdManager
import com.coolvpn.pro.vpn.ConnectionForegroundService
import com.coolvpn.pro.vpn.VpnGateClient
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView

class MainActivity : ComponentActivity() {
    private lateinit var connectButton: Button
    private lateinit var statusText: TextView
    private lateinit var statusHint: TextView
    private lateinit var pingText: TextView
    private lateinit var latencyText: TextView
    private lateinit var countryText: TextView
    private lateinit var serverCountText: TextView
    private lateinit var loading: ProgressBar
    private var connected = false
    private var optimalServer: VpnGateClient.VpnServer? = null
    private lateinit var adManager: AdManager
    private lateinit var bannerAd: AdView

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.getStringExtra(ConnectionForegroundService.EXTRA_STATE)) {
                ConnectionForegroundService.STATE_CONNECTING -> setConnecting()
                ConnectionForegroundService.STATE_CONNECTED -> setConnected()
                ConnectionForegroundService.STATE_DISCONNECTED -> setDisconnected()
                ConnectionForegroundService.STATE_ERROR -> {
                    setDisconnected()
                    Toast.makeText(this@MainActivity, R.string.connection_failed, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        connectButton = findViewById(R.id.connect_button)
        statusText = findViewById(R.id.status_text)
        statusHint = findViewById(R.id.status_hint)
        pingText = findViewById(R.id.ping_text)
        latencyText = findViewById(R.id.latency_value)
        countryText = findViewById(R.id.country_text)
        serverCountText = findViewById(R.id.server_count_text)
        loading = findViewById(R.id.server_loading)

        adManager = AdManager(this)
        adManager.initialize()

        val adContainer = findViewById<View>(R.id.ad_container)
        bannerAd = findViewById<AdView>(R.id.ad_view).apply {
            adUnitId = AdManager.BANNER_TEST_UNIT_ID
            if (adManager.isAdProviderAvailable()) {
                loadAd(AdRequest.Builder().build())
            } else {
                adContainer.visibility = View.GONE
            }
        }

        connectButton.setOnClickListener {
            if (connected) {
                connectButton.isEnabled = false
                setDisconnecting()
                adManager.showDisconnectInterstitial(this) { disconnect() }
            } else {
                requestConnect()
            }
        }
        findViewById<View>(R.id.refresh_button).setOnClickListener { fetchServers() }
        findViewById<View>(R.id.stats_button).setOnClickListener {
            Toast.makeText(this, getString(R.string.stats_preview), Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.remove_ads_button).setOnClickListener {
            Toast.makeText(this, getString(R.string.test_ad), Toast.LENGTH_SHORT).show()
        }
        fetchServers()
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(
            this,
            stateReceiver,
            IntentFilter(ConnectionForegroundService.ACTION_STATE),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onStop() {
        unregisterReceiver(stateReceiver)
        super.onStop()
    }

    private fun fetchServers() {
        loading.visibility = View.VISIBLE
        VpnGateClient.fetchOptimalServer { servers, error ->
            runOnUiThread {
                loading.visibility = View.GONE
                if (error != null || servers.isEmpty()) {
                    serverCountText.text = getString(R.string.server_count_unavailable)
                    Toast.makeText(this, R.string.server_refresh_failed, Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                optimalServer = servers.first()
                countryText.text = getString(
                    R.string.server_country_format,
                    optimalServer?.country ?: getString(R.string.community_server),
                )
                pingText.text = getString(R.string.ping_format, optimalServer?.ping ?: 0)
                latencyText.text = getString(R.string.ping_format, optimalServer?.ping ?: 0)
                serverCountText.text = getString(R.string.server_count_format, servers.size)
            }
        }
    }

    private fun requestConnect() {
        val server = optimalServer
        if (server == null || server.config.isBlank()) {
            Toast.makeText(this, R.string.server_not_ready, Toast.LENGTH_LONG).show()
            return
        }
        connectButton.isEnabled = false
        connect()
        adManager.showConnectInterstitial(this)
    }

    private fun connect() {
        val server = optimalServer
        if (server == null || server.config.isBlank()) {
            Toast.makeText(this, R.string.server_not_ready, Toast.LENGTH_LONG).show()
            return
        }
        setConnecting()
        ConnectionForegroundService.connect(this, server.config, server.hostName)
    }

    private fun disconnect() {
        setDisconnecting()
        ConnectionForegroundService.disconnect(this)
    }

    private fun setConnecting() {
        connectButton.isEnabled = false
        connectButton.setBackgroundResource(R.drawable.button_disconnected)
        connectButton.text = getString(R.string.connecting)
        statusText.text = getString(R.string.connecting)
        statusHint.text = getString(R.string.connecting_hint)
        loading.visibility = View.VISIBLE
    }

    private fun setConnected() {
        connected = true
        connectButton.isEnabled = true
        connectButton.setBackgroundResource(R.drawable.button_connected)
        connectButton.text = getString(R.string.connected)
        statusText.text = getString(R.string.connected)
        statusHint.text = getString(R.string.tap_to_disconnect)
        loading.visibility = View.GONE
    }

    private fun setDisconnecting() {
        connectButton.isEnabled = false
        connectButton.text = getString(R.string.disconnecting)
        statusText.text = getString(R.string.disconnecting)
        statusHint.text = getString(R.string.connecting_hint)
    }

    private fun setDisconnected() {
        connected = false
        connectButton.isEnabled = true
        connectButton.setBackgroundResource(R.drawable.button_disconnected)
        connectButton.text = getString(R.string.disconnected)
        statusText.text = getString(R.string.disconnected)
        statusHint.text = getString(R.string.tap_to_connect)
        loading.visibility = View.GONE
    }

    override fun onResume() {
        super.onResume()
        if (::bannerAd.isInitialized) bannerAd.resume()
    }

    override fun onPause() {
        if (::bannerAd.isInitialized) bannerAd.pause()
        super.onPause()
    }

    override fun onDestroy() {
        if (::bannerAd.isInitialized) bannerAd.destroy()
        super.onDestroy()
    }
}