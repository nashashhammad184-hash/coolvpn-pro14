import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  AppState,
  Modal,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { getCopy, getLanguage, type Language } from '@/lib/i18n';
import {
  chooseOptimalServer,
  fetchVpnGateServers,
  getFallbackServers,
  type VpnServer,
} from '@/lib/vpnGate';

type ConnectionPhase = 'idle' | 'loading' | 'connected' | 'disconnecting' | 'error';

function formatDuration(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
}

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const language = useMemo<Language>(() => getLanguage(), []);
  const copy = getCopy(language);
  const isArabic = language === 'ar';
  const direction = isArabic ? 'rtl' : 'ltr';
  const [phase, setPhase] = useState<ConnectionPhase>('idle');
  const [servers, setServers] = useState<VpnServer[]>(getFallbackServers());
  const [server, setServer] = useState<VpnServer>(chooseOptimalServer(getFallbackServers()));
  const [refreshing, setRefreshing] = useState(false);
  const [serverError, setServerError] = useState(false);
  const [sessionSeconds, setSessionSeconds] = useState(0);
  const [showStats, setShowStats] = useState(false);
  const [showAd, setShowAd] = useState(false);
  const [adPurpose, setAdPurpose] = useState<'open' | 'disconnect'>('open');

  const loadServers = useCallback(async () => {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8500);
    try {
      const freshServers = await fetchVpnGateServers(controller.signal);
      setServers(freshServers);
      setServer(chooseOptimalServer(freshServers));
      setServerError(false);
      await AsyncStorage.setItem('coolvpn.cachedServers', JSON.stringify(freshServers));
    } catch {
      const cached = await AsyncStorage.getItem('coolvpn.cachedServers');
      if (cached) {
        try {
          const cachedServers = JSON.parse(cached) as VpnServer[];
          if (cachedServers.length > 0) {
            setServers(cachedServers);
            setServer(chooseOptimalServer(cachedServers));
          }
        } catch {
          setServer(chooseOptimalServer(getFallbackServers()));
        }
      }
      setServerError(true);
    } finally {
      clearTimeout(timeout);
    }
  }, []);

  useEffect(() => {
    void loadServers();
    const openTimer = setTimeout(() => {
      setAdPurpose('open');
      setShowAd(true);
    }, 400);
    const subscription = AppState.addEventListener('change', (state) => {
      if (state === 'active') void loadServers();
    });
    return () => {
      clearTimeout(openTimer);
      subscription.remove();
    };
  }, [loadServers]);

  useEffect(() => {
    if (phase !== 'connected') return;
    const timer = setInterval(() => setSessionSeconds((value) => value + 1), 1000);
    return () => clearInterval(timer);
  }, [phase]);

  const refresh = async () => {
    setRefreshing(true);
    await loadServers();
    setRefreshing(false);
  };

  const connect = async () => {
    if (phase === 'connected') {
      setAdPurpose('disconnect');
      setShowAd(true);
      return;
    }
    if (phase === 'loading' || phase === 'disconnecting') return;
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setPhase('loading');
    setSessionSeconds(0);
    await new Promise((resolve) => setTimeout(resolve, Platform.OS === 'web' ? 900 : 600));
    if (server.config) {
      setPhase('connected');
    } else {
      setPhase('connected');
    }
  };

  const completeAdAction = async () => {
    setShowAd(false);
    if (adPurpose !== 'disconnect') return;
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setPhase('disconnecting');
    await new Promise((resolve) => setTimeout(resolve, 600));
    setPhase('idle');
    setSessionSeconds(0);
  };

  const statusText =
    phase === 'connected'
      ? copy.connected
      : phase === 'loading'
        ? copy.connecting
        : phase === 'disconnecting'
          ? copy.disconnecting
          : copy.disconnected;
  const actionText = phase === 'connected' ? copy.tapToDisconnect : copy.tapToConnect;
  const isBusy = phase === 'loading' || phase === 'disconnecting';

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <LinearGradient
        colors={['#0B5345', '#0A463B', '#07372E']}
        locations={[0, 0.56, 1]}
        style={StyleSheet.absoluteFill}
      />
      <View pointerEvents="none" style={[styles.orbTop, { backgroundColor: '#1E7E62' }]} />
      <View pointerEvents="none" style={[styles.orbBottom, { backgroundColor: '#0E6250' }]} />
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingTop: insets.top + 14, paddingBottom: Math.max(insets.bottom, 24) + 12 },
        ]}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor={colors.tint} />}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.header, { flexDirection: isArabic ? 'row-reverse' : 'row' }]}>
          <View style={styles.brandMark}>
            <Ionicons name="shield-checkmark" size={23} color={colors.primaryForeground} />
          </View>
          <View style={styles.headerCopy}>
            <Text style={[styles.brand, { color: colors.foreground, textAlign: isArabic ? 'right' : 'left' }]}>
              {copy.appName}
            </Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground, textAlign: isArabic ? 'right' : 'left' }]}>
              {copy.premium}
            </Text>
          </View>
          <Pressable
            accessibilityLabel={copy.removeAds}
            onPress={() => Alert.alert(copy.removeAds, copy.testAd)}
            style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}
          >
            <Ionicons name="sparkles-outline" size={19} color={colors.accent} />
          </Pressable>
        </View>

        <Pressable
          accessibilityLabel={copy.removeAds}
          onPress={() => Alert.alert(copy.removeAds, copy.testAd)}
          style={({ pressed }) => [styles.adBanner, pressed && styles.pressed]}
        >
          <View style={styles.adIcon}>
            <Ionicons name="megaphone-outline" size={17} color={colors.accent} />
          </View>
          <View style={styles.adCopy}>
            <Text style={[styles.adTitle, { color: colors.foreground, textAlign: isArabic ? 'right' : 'left' }]}>
              {copy.removeAds}
            </Text>
            <Text style={[styles.adCaption, { color: colors.mutedForeground, textAlign: isArabic ? 'right' : 'left' }]}>
              {copy.premium}
            </Text>
          </View>
          <Ionicons name={isArabic ? 'chevron-back' : 'chevron-forward'} size={17} color={colors.mutedForeground} />
        </Pressable>

        <View style={[styles.serverCard, { backgroundColor: colors.card, flexDirection: isArabic ? 'row-reverse' : 'row' }]}>
          <View style={styles.serverIcon}>
            <Ionicons name="globe-outline" size={22} color={colors.primary} />
          </View>
          <View style={styles.serverDetails}>
            <View style={[styles.serverLabelRow, { flexDirection: isArabic ? 'row-reverse' : 'row' }]}>
              <Text style={[styles.serverLabel, { color: colors.mutedForeground }]}>{copy.optimalServer}</Text>
              <View style={styles.liveDot} />
            </View>
            <Text style={[styles.serverName, { color: colors.foreground, textAlign: isArabic ? 'right' : 'left' }]}>
              {server.country} · {server.countryCode || server.ip}
            </Text>
            <Text style={[styles.serverSource, { color: colors.mutedForeground, textAlign: isArabic ? 'right' : 'left' }]}>
              {copy.vpnGate}
            </Text>
          </View>
          <View style={styles.ping}>
            <Text style={[styles.pingValue, { color: colors.primary }]}>{server.ping > 3000 ? '—' : server.ping}</Text>
            <Text style={[styles.pingUnit, { color: colors.mutedForeground }]}>ms</Text>
          </View>
        </View>

        <View style={styles.connectionArea}>
          <View style={[styles.ringOuter, { borderColor: phase === 'connected' ? '#6EEDA0' : '#39896E' }]}>
            <View style={[styles.ringInner, { borderColor: phase === 'connected' ? '#A8F2C5' : '#2B7B62' }]}>
              <Pressable
                testID="vpn-connect-button"
                accessibilityRole="button"
                accessibilityLabel={actionText}
                onPress={connect}
                style={({ pressed }) => [
                  styles.connectButton,
                  { backgroundColor: phase === 'connected' ? '#A8F2C5' : '#173F35' },
                  pressed && styles.connectPressed,
                ]}
              >
                {isBusy ? (
                  <ActivityIndicator color={colors.primary} size="small" />
                ) : (
                  <Ionicons
                    name={phase === 'connected' ? 'shield-checkmark' : 'power'}
                    size={37}
                    color={phase === 'connected' ? '#0B5345' : colors.primary}
                  />
                )}
                <Text style={[styles.status, { color: phase === 'connected' ? '#0B5345' : colors.foreground }]}>
                  {statusText}
                </Text>
                <Text style={[styles.actionHint, { color: phase === 'connected' ? '#23674D' : colors.mutedForeground }]}>
                  {actionText}
                </Text>
              </Pressable>
            </View>
          </View>
          <View style={[styles.secureRow, { flexDirection: isArabic ? 'row-reverse' : 'row' }]}>
            <Ionicons name="lock-closed" size={13} color={colors.primary} />
            <Text style={[styles.secureText, { color: colors.mutedForeground }]}>{copy.secureConnection}</Text>
          </View>
        </View>

        <View style={[styles.infoRow, { flexDirection: isArabic ? 'row-reverse' : 'row' }]}>
          <View style={styles.infoItem}>
            <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>{copy.latency}</Text>
            <Text style={[styles.infoValue, { color: colors.foreground }]}>{server.ping > 3000 ? '—' : `${server.ping} ms`}</Text>
          </View>
          <View style={[styles.infoDivider, { backgroundColor: colors.border }]} />
          <View style={styles.infoItem}>
            <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>{copy.sessionTime}</Text>
            <Text style={[styles.infoValue, { color: colors.foreground }]}>{formatDuration(sessionSeconds)}</Text>
          </View>
          <View style={[styles.infoDivider, { backgroundColor: colors.border }]} />
          <View style={styles.infoItem}>
            <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>{copy.serverCount}</Text>
            <Text style={[styles.infoValue, { color: colors.foreground }]}>{servers.length}</Text>
          </View>
        </View>

        {serverError && (
          <Pressable onPress={refresh} style={({ pressed }) => [styles.notice, { borderColor: colors.border }, pressed && styles.pressed]}>
            <Ionicons name="refresh-outline" size={16} color={colors.accent} />
            <Text style={[styles.noticeText, { color: colors.mutedForeground }]}>{copy.noServers}</Text>
            <Text style={[styles.retry, { color: colors.accent }]}>{copy.retry}</Text>
          </Pressable>
        )}

        <View style={[styles.bottomNav, { borderTopColor: colors.border, flexDirection: isArabic ? 'row-reverse' : 'row' }]}>
          <Pressable
            testID="stats-button"
            accessibilityLabel={copy.dataStatistics}
            onPress={() => setShowStats(true)}
            style={({ pressed }) => [styles.navItem, pressed && styles.pressed]}
          >
            <Ionicons name="stats-chart-outline" size={21} color={colors.mutedForeground} />
            <Text style={[styles.navText, { color: colors.mutedForeground }]}>{copy.dataStatistics}</Text>
          </Pressable>
          <Pressable
            accessibilityLabel={copy.refreshServers}
            onPress={refresh}
            style={({ pressed }) => [styles.navItem, pressed && styles.pressed]}
          >
            <Ionicons name="sync-outline" size={21} color={colors.mutedForeground} />
            <Text style={[styles.navText, { color: colors.mutedForeground }]}>{copy.refreshServers}</Text>
          </Pressable>
        </View>
      </ScrollView>

      <Modal visible={showAd} transparent animationType="fade" onRequestClose={() => setShowAd(false)}>
        <View style={styles.modalBackdrop}>
          <View style={[styles.adModal, { backgroundColor: '#F1FFF7' }]}>
            <View style={styles.adModalIcon}>
              <Ionicons name="sparkles" size={24} color="#0B5345" />
            </View>
            <Text style={styles.adModalTitle}>{copy.testAd}</Text>
            <Text style={styles.adModalBody}>
              {adPurpose === 'disconnect' ? copy.continueDisconnect : copy.previewModeBody}
            </Text>
            <Pressable onPress={completeAdAction} style={({ pressed }) => [styles.adContinue, pressed && styles.pressed]}>
              <Text style={styles.adContinueText}>
                {adPurpose === 'disconnect' ? copy.continueDisconnect : copy.close}
              </Text>
            </Pressable>
            {adPurpose === 'disconnect' && (
              <Pressable onPress={() => setShowAd(false)} style={styles.cancelButton}>
                <Text style={styles.cancelText}>{copy.cancel}</Text>
              </Pressable>
            )}
          </View>
        </View>
      </Modal>

      <Modal visible={showStats} transparent animationType="slide" onRequestClose={() => setShowStats(false)}>
        <View style={styles.modalBackdrop}>
          <View style={[styles.statsModal, { backgroundColor: colors.card }]}>
            <View style={[styles.statsHeader, { flexDirection: isArabic ? 'row-reverse' : 'row' }]}>
              <Text style={[styles.statsTitle, { color: colors.foreground }]}>{copy.dataStatistics}</Text>
              <Pressable onPress={() => setShowStats(false)} style={({ pressed }) => [styles.closeButton, pressed && styles.pressed]}>
                <Ionicons name="close" size={22} color={colors.mutedForeground} />
              </Pressable>
            </View>
            <View style={styles.statLine}>
              <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>{copy.sessionTime}</Text>
              <Text style={[styles.infoValue, { color: colors.foreground }]}>{formatDuration(sessionSeconds)}</Text>
            </View>
            <View style={styles.statLine}>
              <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>{copy.dataUsed}</Text>
              <Text style={[styles.infoValue, { color: colors.foreground }]}>{phase === 'connected' ? '0.0 MB' : '—'}</Text>
            </View>
            <Text style={[styles.previewLabel, { color: colors.mutedForeground }]}>{copy.previewMode}</Text>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 20 },
  orbTop: { position: 'absolute', width: 280, height: 280, borderRadius: 140, top: -170, left: -115, opacity: 0.45 },
  orbBottom: { position: 'absolute', width: 300, height: 300, borderRadius: 150, bottom: -180, right: -120, opacity: 0.4 },
  header: { alignItems: 'center', gap: 11, marginBottom: 21 },
  brandMark: { width: 46, height: 46, borderRadius: 16, backgroundColor: '#A8F2C5', alignItems: 'center', justifyContent: 'center' },
  headerCopy: { flex: 1 },
  brand: { fontSize: 20, fontWeight: '700', letterSpacing: 0.2 },
  subtitle: { fontSize: 12, marginTop: 3 },
  iconButton: { width: 40, height: 40, borderRadius: 14, backgroundColor: 'rgba(255,255,255,0.10)', alignItems: 'center', justifyContent: 'center' },
  adBanner: { minHeight: 66, borderRadius: 20, paddingHorizontal: 15, paddingVertical: 12, backgroundColor: 'rgba(255,255,255,0.09)', borderWidth: 1, borderColor: 'rgba(216,251,229,0.16)', flexDirection: 'row', alignItems: 'center', gap: 11, marginBottom: 15 },
  adIcon: { width: 36, height: 36, borderRadius: 12, backgroundColor: 'rgba(248,212,122,0.16)', alignItems: 'center', justifyContent: 'center' },
  adCopy: { flex: 1 },
  adTitle: { fontSize: 14, fontWeight: '700' },
  adCaption: { fontSize: 11, marginTop: 2 },
  serverCard: { borderRadius: 21, padding: 15, alignItems: 'center', gap: 12, borderWidth: 1, borderColor: 'rgba(216,251,229,0.14)' },
  serverIcon: { width: 45, height: 45, borderRadius: 15, backgroundColor: 'rgba(168,242,197,0.13)', alignItems: 'center', justifyContent: 'center' },
  serverDetails: { flex: 1 },
  serverLabelRow: { alignItems: 'center', gap: 7, marginBottom: 3 },
  serverLabel: { fontSize: 11, fontWeight: '600' },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#A8F2C5' },
  serverName: { fontSize: 14, fontWeight: '700' },
  serverSource: { fontSize: 10, marginTop: 4 },
  ping: { alignItems: 'flex-end', minWidth: 45 },
  pingValue: { fontSize: 21, fontWeight: '700' },
  pingUnit: { fontSize: 10, marginTop: -2 },
  connectionArea: { alignItems: 'center', paddingVertical: 27 },
  ringOuter: { width: 226, height: 226, borderRadius: 113, borderWidth: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(0,0,0,0.04)' },
  ringInner: { width: 196, height: 196, borderRadius: 98, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  connectButton: { width: 168, height: 168, borderRadius: 84, alignItems: 'center', justifyContent: 'center', shadowColor: '#021A15', shadowOpacity: 0.2, shadowRadius: 14, shadowOffset: { width: 0, height: 8 }, elevation: 8 },
  connectPressed: { transform: [{ scale: 0.965 }], opacity: 0.92 },
  status: { fontSize: 17, fontWeight: '700', marginTop: 9 },
  actionHint: { fontSize: 11, marginTop: 4 },
  secureRow: { alignItems: 'center', gap: 5, marginTop: 18 },
  secureText: { fontSize: 11 },
  infoRow: { minHeight: 78, borderRadius: 20, backgroundColor: 'rgba(0,0,0,0.10)', alignItems: 'center', justifyContent: 'space-evenly', marginBottom: 14 },
  infoItem: { flex: 1, alignItems: 'center', gap: 5 },
  infoLabel: { fontSize: 10 },
  infoValue: { fontSize: 14, fontWeight: '700' },
  infoDivider: { width: 1, height: 27, opacity: 0.55 },
  notice: { minHeight: 42, borderRadius: 14, borderWidth: 1, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 },
  noticeText: { flex: 1, fontSize: 11 },
  retry: { fontSize: 11, fontWeight: '700' },
  bottomNav: { borderTopWidth: 1, minHeight: 70, alignItems: 'center', justifyContent: 'space-around', marginTop: 'auto' },
  navItem: { alignItems: 'center', justifyContent: 'center', gap: 6, paddingHorizontal: 18, paddingVertical: 10 },
  navText: { fontSize: 10 },
  pressed: { opacity: 0.72 },
  modalBackdrop: { flex: 1, backgroundColor: 'rgba(1, 20, 16, 0.72)', alignItems: 'center', justifyContent: 'center', padding: 24 },
  adModal: { width: '100%', maxWidth: 360, borderRadius: 26, padding: 25, alignItems: 'center' },
  adModalIcon: { width: 52, height: 52, borderRadius: 18, backgroundColor: '#C8F8D8', alignItems: 'center', justifyContent: 'center', marginBottom: 15 },
  adModalTitle: { color: '#0B5345', fontSize: 19, fontWeight: '800' },
  adModalBody: { color: '#527066', textAlign: 'center', lineHeight: 20, fontSize: 13, marginTop: 8, marginBottom: 20 },
  adContinue: { width: '100%', backgroundColor: '#0B5345', borderRadius: 15, paddingVertical: 14, alignItems: 'center' },
  adContinueText: { color: '#F1FFF7', fontWeight: '700', fontSize: 14 },
  cancelButton: { paddingVertical: 13 },
  cancelText: { color: '#527066', fontSize: 13, fontWeight: '600' },
  statsModal: { width: '100%', maxWidth: 380, borderRadius: 26, padding: 23 },
  statsHeader: { alignItems: 'center', justifyContent: 'space-between', marginBottom: 21 },
  statsTitle: { fontSize: 20, fontWeight: '800' },
  closeButton: { padding: 4 },
  statLine: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.10)' },
  previewLabel: { fontSize: 10, textAlign: 'center', marginTop: 19 },
});