export type Language = 'ar' | 'en';

export type Copy = {
  appName: string;
  premium: string;
  removeAds: string;
  optimalServer: string;
  refreshServers: string;
  latency: string;
  disconnected: string;
  connected: string;
  connecting: string;
  disconnecting: string;
  tapToConnect: string;
  tapToDisconnect: string;
  secureConnection: string;
  dataStatistics: string;
  sessionTime: string;
  dataUsed: string;
  serverCount: string;
  vpnGate: string;
  noServers: string;
  retry: string;
  previewMode: string;
  previewModeBody: string;
  testAd: string;
  continueDisconnect: string;
  cancel: string;
  connectionFailed: string;
  connectionFailedBody: string;
  close: string;
};

const translations: Record<Language, Copy> = {
  ar: {
    appName: 'كول VPN برو',
    premium: 'اتصال خاص وسريع',
    removeAds: 'إزالة الإعلانات',
    optimalServer: 'الخادم الأمثل',
    refreshServers: 'تحديث الخوادم',
    latency: 'زمن الاستجابة',
    disconnected: 'انقطع الاتصال',
    connected: 'تم الاتصال',
    connecting: 'جارٍ الاتصال',
    disconnecting: 'جارٍ الفصل',
    tapToConnect: 'اضغط للاتصال',
    tapToDisconnect: 'اضغط للفصل',
    secureConnection: 'اتصال مشفّر وآمن',
    dataStatistics: 'إحصائيات البيانات',
    sessionTime: 'مدة الجلسة',
    dataUsed: 'البيانات المستخدمة',
    serverCount: 'خادم متاح',
    vpnGate: 'المصدر: VPN Gate',
    noServers: 'تعذّر تحديث قائمة الخوادم',
    retry: 'إعادة المحاولة',
    previewMode: 'وضع المعاينة',
    previewModeBody: 'المعاينة تعرض تجربة الزر. اتصال OpenVPN الكامل يعمل من نسخة Android الأصلية.',
    testAd: 'إعلان تجريبي',
    continueDisconnect: 'متابعة الفصل',
    cancel: 'إلغاء',
    connectionFailed: 'تعذّر الاتصال',
    connectionFailedBody: 'الخادم المجاني قد يكون غير متاح. جرّب تحديث قائمة الخوادم.',
    close: 'إغلاق',
  },
  en: {
    appName: 'CoolVPN Pro',
    premium: 'Private, faster connection',
    removeAds: 'Remove Ads',
    optimalServer: 'Optimal Server',
    refreshServers: 'Refresh servers',
    latency: 'Latency',
    disconnected: 'Disconnected',
    connected: 'Connected',
    connecting: 'Connecting',
    disconnecting: 'Disconnecting',
    tapToConnect: 'Tap to connect',
    tapToDisconnect: 'Tap to disconnect',
    secureConnection: 'Encrypted and secure connection',
    dataStatistics: 'Data statistics',
    sessionTime: 'Session time',
    dataUsed: 'Data used',
    serverCount: 'servers available',
    vpnGate: 'Source: VPN Gate',
    noServers: 'Could not refresh the server list',
    retry: 'Retry',
    previewMode: 'Preview mode',
    previewModeBody: 'The preview demonstrates the button flow. Full OpenVPN tunneling is available from the native Android build.',
    testAd: 'Test ad',
    continueDisconnect: 'Continue disconnecting',
    cancel: 'Cancel',
    connectionFailed: 'Connection failed',
    connectionFailedBody: 'The free server may be unavailable. Try refreshing the server list.',
    close: 'Close',
  },
};

export function getLanguage(): Language {
  const languageCode = Intl.DateTimeFormat().resolvedOptions().locale.split('-')[0]?.toLowerCase();
  return languageCode === 'ar' ? 'ar' : 'en';
}

export function getCopy(language: Language): Copy {
  return translations[language];
}