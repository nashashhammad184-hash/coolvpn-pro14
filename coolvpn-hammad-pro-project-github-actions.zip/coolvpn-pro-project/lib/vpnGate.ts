export type VpnServer = {
  hostName: string;
  ip: string;
  country: string;
  countryCode: string;
  speed: number;
  ping: number;
  sessions: number;
  config: string;
};

const VPN_GATE_ENDPOINT = 'https://www.vpngate.net/api/iphone/';

const fallbackServers: VpnServer[] = [
  {
    hostName: 'community-tokyo',
    ip: 'public-directory',
    country: 'Japan',
    countryCode: 'JP',
    speed: 72000000,
    ping: 63,
    sessions: 12,
    config: '',
  },
  {
    hostName: 'community-frankfurt',
    ip: 'public-directory',
    country: 'Germany',
    countryCode: 'DE',
    speed: 54000000,
    ping: 88,
    sessions: 18,
    config: '',
  },
];

function csvFields(line: string): string[] {
  const result: string[] = [];
  let field = '';
  let quoted = false;
  for (const character of line) {
    if (character === '"') {
      quoted = !quoted;
    } else if (character === ',' && !quoted) {
      result.push(field);
      field = '';
    } else {
      field += character;
    }
  }
  result.push(field);
  return result.map((value) => value.trim().replace(/^"|"$/g, ''));
}

function numberAt(fields: string[], index: number, fallback: number): number {
  const value = Number(fields[index]);
  return Number.isFinite(value) ? value : fallback;
}

export function parseVpnGateCsv(csv: string): VpnServer[] {
  const lines = csv
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  const headerIndex = lines.findIndex((line) => line.replace(/^#/, '').startsWith('HostName,'));
  if (headerIndex < 0 || lines.length <= headerIndex + 1) return [];

  const headers = csvFields(lines[headerIndex].replace(/^#/, '')).map((header) => header.toLowerCase());
  const indexOf = (name: string) => headers.indexOf(name.toLowerCase());
  const hostNameIndex = indexOf('HostName');
  const ipIndex = indexOf('IP');
  const countryIndex = indexOf('CountryLong');
  const countryCodeIndex = indexOf('CountryShort');
  const speedIndex = indexOf('Speed');
  const pingIndex = indexOf('Ping');
  const sessionsIndex = indexOf('NumVpnSessions');
  const configIndex = indexOf('OpenVPN_ConfigData_Base64');

  return lines
    .slice(headerIndex + 1)
    .filter((line) => !line.startsWith('#'))
    .map((line) => csvFields(line))
    .map((fields) => ({
      hostName: fields[hostNameIndex] || 'community-server',
      ip: fields[ipIndex] || '',
      country: fields[countryIndex] || 'Community',
      countryCode: fields[countryCodeIndex] || '',
      speed: numberAt(fields, speedIndex, 0),
      ping: numberAt(fields, pingIndex, 9999),
      sessions: numberAt(fields, sessionsIndex, 0),
      config: fields[configIndex] || '',
    }))
    .filter((server) => server.ip && server.ping > 0 && server.ping < 3000)
    .sort((a, b) => a.ping - b.ping)
    .slice(0, 20);
}

export async function fetchVpnGateServers(signal?: AbortSignal): Promise<VpnServer[]> {
  const isWebPreview = typeof window !== 'undefined';
  const endpoint = isWebPreview ? '/api/vpngate/servers' : VPN_GATE_ENDPOINT;
  const response = await fetch(endpoint, {
    signal,
    headers: { Accept: 'text/plain' },
  });
  if (!response.ok) throw new Error(`VPN Gate returned ${response.status}`);
  const servers = isWebPreview
    ? parseVpnGateCsv((await response.json() as { csv?: string }).csv ?? '')
    : parseVpnGateCsv(await response.text());
  if (servers.length === 0) throw new Error('VPN Gate returned no usable servers');
  return servers;
}

export function getFallbackServers(): VpnServer[] {
  return fallbackServers;
}

export function chooseOptimalServer(servers: VpnServer[]): VpnServer {
  return [...servers].sort((a, b) => a.ping - b.ping)[0] ?? fallbackServers[0];
}