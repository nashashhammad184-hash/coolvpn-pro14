# CoolVPN Pro

CoolVPN Pro is a no-account, one-tap Android VPN client with an Arabic-first
interface and an English system-language override. The preview app under
`app/` is Expo-based so it can be opened in Replit's mobile preview. The
`android/` directory is a standalone Android Studio project for the native
OpenVPN and AdMob behavior.

## Android Studio build

1. Open the `android` directory in Android Studio.
2. Let Gradle sync and install the Android SDK 35 platform if requested.
3. Run the `app` configuration on an Android device or emulator.
4. Build an APK with `./gradlew assembleDebug` from the `android` directory
   when the Gradle wrapper is available, or use **Build > Build APK(s)**.

## GitHub Actions release build

The extracted project includes `.github/workflows/android.yml`. A push to any
branch or a manual workflow run builds and uploads:

- `app-release.apk`
- `app-release.aab`

The workflow uses GitHub's Ubuntu runner, Java 17, Gradle 8.10.2, and creates
the release keystore in the runner when needed. For stable app updates, add
these GitHub Actions secrets before publishing:

- `COOLVPN_KEYSTORE_BASE64`
- `COOLVPN_KEYSTORE_PASSWORD`
- `COOLVPN_KEY_ALIAS` (optional; defaults to `coolvpn-release`)
- `COOLVPN_KEY_PASSWORD` (optional; defaults to the store password)

If the persistent keystore secrets are absent, the workflow still creates
signed artifacts for testing, but its ephemeral key cannot sign future updates
over the same installed app.

The native project uses the open-source ICS OpenVPN library and imports the
OpenVPN configuration returned by VPN Gate's public directory. The first
native connection asks Android for VPN permission, then launches the selected
profile through the library's secure tunnel implementation.

## Free server behavior

On each app open, the client requests the public VPN Gate CSV directory, parses
the OpenVPN profile payload, sorts usable entries by reported ping, and uses
the lowest-latency server. The directory is community-operated: servers can
disappear, be slow, or reject connections. A failed refresh is surfaced rather
than silently claiming the connection is secure. Cached entries are used only
when the last known list is available.

## Ads

The native Android project uses Google's official development test units:

- interstitial: `ca-app-pub-3940256099942544/1033173712`
- banner: `ca-app-pub-3940256099942544/6300978111`

No App Open ad is loaded or shown. The central button shows an interstitial
only as a delayed, ready-only attempt after the connect request has started,
so the VPN is never blocked by ad loading. The disconnect action briefly holds
the disconnecting state, shows a preloaded interstitial when available, and
only completes the disconnect after dismissal; if no ad is ready, it completes
without blocking. A small banner remains pinned to a dedicated bottom slot
with scroll clearance. Replace test units only for a signed production release.

## Store distribution and ad-provider limits

- The package/application ID is `com.coolvpn.pro`.
- The connection service declares Android 14 `specialUse` foreground-service
  permission and subtype metadata. Google Play still requires the matching
  foreground-service declaration during Play Console review.
- Google Mobile Ads is guarded by a Google Play Services availability check.
  On Huawei or Amazon devices without GMS, unsupported Google ad calls are
  skipped safely instead of crashing the app.
- AppLovin MAX is not enabled with a fake key. MAX requires an
  account-specific SDK key, mediation configuration, network adapters, and
  privacy/store declarations; it has no universal global placeholder key that
  can serve production ads across every store.

The source is therefore cross-store install-safe, but no source archive can
make monetization or store approval production-ready without the publisher's
real ad-network accounts, signing credentials, privacy declarations, and
store-specific review submissions.

## Localization

- `android/app/src/main/res/values/strings.xml` is the Arabic default.
- `android/app/src/main/res/values-en/strings.xml` is the English override.
- The Expo preview resolves the system locale at runtime and uses the same
  Arabic/English copy.

No registration, login, email collection, or subscription flow is included.