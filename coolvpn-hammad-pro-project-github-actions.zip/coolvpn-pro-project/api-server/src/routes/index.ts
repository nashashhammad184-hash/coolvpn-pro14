import { Router, type IRouter } from "express";
import healthRouter from "./health";
import vpngateRouter from "./vpngate";

const router: IRouter = Router();

router.use(healthRouter);
router.use(vpngateRouter);

export default router;
