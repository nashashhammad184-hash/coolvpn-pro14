import { Router, type IRouter } from "express";

const router: IRouter = Router();
const VPN_GATE_ENDPOINT = "https://www.vpngate.net/api/iphone/";

router.get("/vpngate/servers", async (_req, res) => {
  try {
    const response = await fetch(VPN_GATE_ENDPOINT, {
      headers: { Accept: "text/plain" },
    });
    if (!response.ok) {
      res.status(502).json({ error: `VPN Gate returned ${response.status}` });
      return;
    }
    res.json({ csv: await response.text(), fetchedAt: new Date().toISOString() });
  } catch {
    res.status(502).json({ error: "VPN Gate is unavailable" });
  }
});

export default router;